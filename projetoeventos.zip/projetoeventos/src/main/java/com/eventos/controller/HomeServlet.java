package com.eventos.controller;

import com.eventos.dao.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Estatísticas para o dashboard
        EventoDAO eventoDAO = new EventoDAO();
        LocalDAO localDAO = new LocalDAO();
        PalestranteDAO palestranteDAO = new PalestranteDAO();
        ParticipanteDAO participanteDAO = new ParticipanteDAO();
        
        request.setAttribute("totalEventos", eventoDAO.listar().size());
        request.setAttribute("totalLocais", localDAO.listar().size());
        request.setAttribute("totalPalestrantes", palestranteDAO.listar().size());
        request.setAttribute("totalParticipantes", participanteDAO.listar().size());
        request.setAttribute("eventosRecentes", eventoDAO.listar());
        
        request.getRequestDispatcher("/WEB-INF/views/home.jsp").forward(request, response);
    }
}