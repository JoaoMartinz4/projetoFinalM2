package com.eventos.controller;

import com.eventos.dao.PalestranteDAO;
import com.eventos.model.Palestrante;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/palestrante")
public class PalestranteServlet extends HttpServlet {
    private PalestranteDAO palestranteDAO = new PalestranteDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) action = "listar";
        
        switch (action) {
            case "novo":
                request.getRequestDispatcher("/WEB-INF/views/palestrante/form.jsp").forward(request, response);
                break;
            case "editar":
                int id = Integer.parseInt(request.getParameter("id"));
                Palestrante palestrante = palestranteDAO.buscarPorId(id);
                request.setAttribute("palestrante", palestrante);
                request.getRequestDispatcher("/WEB-INF/views/palestrante/form.jsp").forward(request, response);
                break;
            case "deletar":
                int idDeletar = Integer.parseInt(request.getParameter("id"));
                palestranteDAO.deletar(idDeletar);
                response.sendRedirect("palestrante");
                break;
            default:
                request.setAttribute("palestrantes", palestranteDAO.listar());
                request.getRequestDispatcher("/WEB-INF/views/palestrante/lista.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        Palestrante palestrante = new Palestrante();
        palestrante.setNome(request.getParameter("nome"));
        palestrante.setEmail(request.getParameter("email"));
        palestrante.setEspecialidade(request.getParameter("especialidade"));
        
        String id = request.getParameter("id");
        if (id != null && !id.isEmpty()) {
            palestrante.setId(Integer.parseInt(id));
            palestranteDAO.atualizar(palestrante);
        } else {
            palestranteDAO.inserir(palestrante);
        }
        
        response.sendRedirect("palestrante");
    }
}