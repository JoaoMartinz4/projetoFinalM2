package com.eventos.controller;

import com.eventos.dao.*;
import com.eventos.model.Evento;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/evento")
public class EventoServlet extends HttpServlet {
    private EventoDAO eventoDAO = new EventoDAO();
    private LocalDAO localDAO = new LocalDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) action = "listar";
        
        switch (action) {
            case "novo":
                request.setAttribute("locais", localDAO.listar());
                request.getRequestDispatcher("/WEB-INF/views/evento/form.jsp").forward(request, response);
                break;
            case "editar":
                int id = Integer.parseInt(request.getParameter("id"));
                Evento evento = eventoDAO.buscarPorId(id);
                request.setAttribute("evento", evento);
                request.setAttribute("locais", localDAO.listar());
                request.getRequestDispatcher("/WEB-INF/views/evento/form.jsp").forward(request, response);
                break;
            case "deletar":
                int idDeletar = Integer.parseInt(request.getParameter("id"));
                eventoDAO.deletar(idDeletar);
                response.sendRedirect("evento");
                break;
            default:
                request.setAttribute("eventos", eventoDAO.listar());
                request.getRequestDispatcher("/WEB-INF/views/evento/lista.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        Evento evento = new Evento();
        evento.setNome(request.getParameter("nome"));
        evento.setDescricao(request.getParameter("descricao"));
        evento.setData(request.getParameter("data"));
        evento.setHora(request.getParameter("hora"));
        evento.setIdLocal(Integer.parseInt(request.getParameter("idLocal")));
        
        String id = request.getParameter("id");
        if (id != null && !id.isEmpty()) {
            evento.setId(Integer.parseInt(id));
            eventoDAO.atualizar(evento);
        } else {
            eventoDAO.inserir(evento);
        }
        
        response.sendRedirect("evento");
    }
}