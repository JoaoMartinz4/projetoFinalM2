package com.eventos.controller;

import com.eventos.dao.LocalDAO;
import com.eventos.model.Local;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/local")
public class LocalServlet extends HttpServlet {
    private LocalDAO localDAO = new LocalDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) action = "listar";
        
        switch (action) {
            case "novo":
                request.getRequestDispatcher("/WEB-INF/views/local/form.jsp").forward(request, response);
                break;
            case "editar":
                int id = Integer.parseInt(request.getParameter("id"));
                Local local = localDAO.buscarPorId(id);
                request.setAttribute("local", local);
                request.getRequestDispatcher("/WEB-INF/views/local/form.jsp").forward(request, response);
                break;
            case "deletar":
                int idDeletar = Integer.parseInt(request.getParameter("id"));
                localDAO.deletar(idDeletar);
                response.sendRedirect("local");
                break;
            default:
                request.setAttribute("locais", localDAO.listar());
                request.getRequestDispatcher("/WEB-INF/views/local/lista.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        Local local = new Local();
        local.setNome(request.getParameter("nome"));
        local.setEndereco(request.getParameter("endereco"));
        local.setCapacidade(Integer.parseInt(request.getParameter("capacidade")));
        
        String id = request.getParameter("id");
        if (id != null && !id.isEmpty()) {
            local.setId(Integer.parseInt(id));
            localDAO.atualizar(local);
        } else {
            localDAO.inserir(local);
        }
        
        response.sendRedirect("local");
    }
}