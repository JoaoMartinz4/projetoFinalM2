package com.eventos.controller;

import com.eventos.dao.*;
import com.eventos.model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/inscricao")
public class InscricaoServlet extends HttpServlet {
    private EventoInscricaoDAO inscricaoDAO = new EventoInscricaoDAO();
    private EventoDAO eventoDAO = new EventoDAO();
    private ParticipanteDAO participanteDAO = new ParticipanteDAO();
    private PalestranteDAO palestranteDAO = new PalestranteDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) action = "listar";
        
        switch (action) {
            case "gerenciar":
                int eventoId = Integer.parseInt(request.getParameter("eventoId"));
                Evento evento = eventoDAO.buscarPorId(eventoId);
                
                // Lista participantes já inscritos
                List<Participante> participantesInscritos = inscricaoDAO.listarParticipantes(eventoId);
                
                // Lista todos os participantes disponíveis
                List<Participante> todosParticipantes = participanteDAO.listar();
                
                // Lista palestrantes do evento
                List<Palestrante> palestrantesEvento = inscricaoDAO.listarPalestrantes(eventoId);
                
                // Lista todos os palestrantes disponíveis
                List<Palestrante> todosPalestrantes = palestranteDAO.listar();
                
                request.setAttribute("evento", evento);
                request.setAttribute("participantesInscritos", participantesInscritos);
                request.setAttribute("todosParticipantes", todosParticipantes);
                request.setAttribute("palestrantesEvento", palestrantesEvento);
                request.setAttribute("todosPalestrantes", todosPalestrantes);
                
                request.getRequestDispatcher("/WEB-INF/views/inscricao/gerenciar.jsp").forward(request, response);
                break;
                
            case "adicionarParticipante":
                int evtId = Integer.parseInt(request.getParameter("eventoId"));
                int partId = Integer.parseInt(request.getParameter("participanteId"));
                inscricaoDAO.adicionarParticipante(evtId, partId);
                response.sendRedirect("inscricao?action=gerenciar&eventoId=" + evtId);
                break;
                
            case "removerParticipante":
                int evId = Integer.parseInt(request.getParameter("eventoId"));
                int paId = Integer.parseInt(request.getParameter("participanteId"));
                inscricaoDAO.removerParticipante(evId, paId);
                response.sendRedirect("inscricao?action=gerenciar&eventoId=" + evId);
                break;
                
            case "adicionarPalestrante":
                int eId = Integer.parseInt(request.getParameter("eventoId"));
                int palId = Integer.parseInt(request.getParameter("palestranteId"));
                inscricaoDAO.adicionarPalestrante(eId, palId);
                response.sendRedirect("inscricao?action=gerenciar&eventoId=" + eId);
                break;
                
            case "removerPalestrante":
                int eventId = Integer.parseInt(request.getParameter("eventoId"));
                int paleId = Integer.parseInt(request.getParameter("palestranteId"));
                inscricaoDAO.removerPalestrante(eventId, paleId);
                response.sendRedirect("inscricao?action=gerenciar&eventoId=" + eventId);
                break;
                
            default:
                // Lista todos os eventos com contagem de participantes
                List<Evento> eventos = eventoDAO.listar();
                for (Evento evt : eventos) {
                    evt.setParticipantes(inscricaoDAO.listarParticipantes(evt.getId()));
                    evt.setPalestrantes(inscricaoDAO.listarPalestrantes(evt.getId()));
                }
                request.setAttribute("eventos", eventos);
                request.getRequestDispatcher("/WEB-INF/views/inscricao/lista.jsp").forward(request, response);
        }
    }
}