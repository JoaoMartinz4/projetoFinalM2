package com.eventos.controller;

import com.eventos.dao.ParticipanteDAO;
import com.eventos.model.Participante;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/participante")
public class ParticipanteServlet extends HttpServlet {
    private ParticipanteDAO participanteDAO = new ParticipanteDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) action = "listar";
        
        switch (action) {
            case "novo":
                request.getRequestDispatcher("/WEB-INF/views/participante/form.jsp").forward(request, response);
                break;
            case "editar":
                int id = Integer.parseInt(request.getParameter("id"));
                Participante participante = participanteDAO.buscarPorId(id);
                request.setAttribute("participante", participante);
                request.getRequestDispatcher("/WEB-INF/views/participante/form.jsp").forward(request, response);
                break;
            case "deletar":
                int idDeletar = Integer.parseInt(request.getParameter("id"));
                participanteDAO.deletar(idDeletar);
                response.sendRedirect("participante");
                break;
            default:
                request.setAttribute("participantes", participanteDAO.listar());
                request.getRequestDispatcher("/WEB-INF/views/participante/lista.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        Participante participante = new Participante();
        participante.setNome(request.getParameter("nome"));
        participante.setEmail(request.getParameter("email"));
        participante.setTelefone(request.getParameter("telefone"));
        
        String id = request.getParameter("id");
        if (id != null && !id.isEmpty()) {
            participante.setId(Integer.parseInt(id));
            participanteDAO.atualizar(participante);
        } else {
            participanteDAO.inserir(participante);
        }
        
        response.sendRedirect("participante");
    }
}