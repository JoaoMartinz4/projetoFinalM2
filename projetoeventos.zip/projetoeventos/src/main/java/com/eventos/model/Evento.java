package com.eventos.model;

import java.util.List;

public class Evento {
    private int id;
    private String nome;
    private String descricao;
    private String data;
    private String hora;
    private int idLocal;
    private Local local;
    private List<Palestrante> palestrantes;
    private List<Participante> participantes;
    
    public Evento() {}
    
    public Evento(int id, String nome, String descricao, String data, String hora, int idLocal) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.data = data;
        this.hora = hora;
        this.idLocal = idLocal;
    }
    
    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    
    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
    
    public String getHora() { return hora; }
    public void setHora(String hora) { this.hora = hora; }
    
    public int getIdLocal() { return idLocal; }
    public void setIdLocal(int idLocal) { this.idLocal = idLocal; }
    
    public Local getLocal() { return local; }
    public void setLocal(Local local) { this.local = local; }
    
    public List<Palestrante> getPalestrantes() { return palestrantes; }
    public void setPalestrantes(List<Palestrante> palestrantes) { this.palestrantes = palestrantes; }
    
    public List<Participante> getParticipantes() { return participantes; }
    public void setParticipantes(List<Participante> participantes) { this.participantes = participantes; }
}