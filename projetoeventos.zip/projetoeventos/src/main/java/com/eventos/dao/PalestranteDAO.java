package com.eventos.dao;

import com.eventos.model.Palestrante;
import com.eventos.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PalestranteDAO {
    
    public boolean inserir(Palestrante palestrante) {
        String sql = "INSERT INTO palestrante (nome, email, especialidade) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, palestrante.getNome());
            stmt.setString(2, palestrante.getEmail());
            stmt.setString(3, palestrante.getEspecialidade());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Palestrante> listar() {
        List<Palestrante> palestrantes = new ArrayList<>();
        String sql = "SELECT * FROM palestrante ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Palestrante palestrante = new Palestrante();
                palestrante.setId(rs.getInt("pk_id"));
                palestrante.setNome(rs.getString("nome"));
                palestrante.setEmail(rs.getString("email"));
                palestrante.setEspecialidade(rs.getString("especialidade"));
                palestrantes.add(palestrante);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return palestrantes;
    }
    
    public Palestrante buscarPorId(int id) {
        String sql = "SELECT * FROM palestrante WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Palestrante palestrante = new Palestrante();
                palestrante.setId(rs.getInt("pk_id"));
                palestrante.setNome(rs.getString("nome"));
                palestrante.setEmail(rs.getString("email"));
                palestrante.setEspecialidade(rs.getString("especialidade"));
                return palestrante;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean atualizar(Palestrante palestrante) {
        String sql = "UPDATE palestrante SET nome = ?, email = ?, especialidade = ? WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, palestrante.getNome());
            stmt.setString(2, palestrante.getEmail());
            stmt.setString(3, palestrante.getEspecialidade());
            stmt.setInt(4, palestrante.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deletar(int id) {
        String sql = "DELETE FROM palestrante WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}