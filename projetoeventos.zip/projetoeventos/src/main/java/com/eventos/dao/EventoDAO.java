package com.eventos.dao;

import com.eventos.model.Evento;
import com.eventos.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventoDAO {
    
    public boolean inserir(Evento evento) {
        String sql = "INSERT INTO evento (nome, descricao, data, hora, fk_id_local) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, evento.getNome());
            stmt.setString(2, evento.getDescricao());
            stmt.setString(3, evento.getData());
            stmt.setString(4, evento.getHora());
            stmt.setInt(5, evento.getIdLocal());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Evento> listar() {
        List<Evento> eventos = new ArrayList<>();
        String sql = "SELECT e.*, l.nome as local_nome FROM evento e " +
                     "LEFT JOIN local l ON e.fk_id_local = l.pk_id " +
                     "ORDER BY e.data DESC, e.hora DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            LocalDAO localDAO = new LocalDAO();
            while (rs.next()) {
                Evento evento = new Evento();
                evento.setId(rs.getInt("pk_id"));
                evento.setNome(rs.getString("nome"));
                evento.setDescricao(rs.getString("descricao"));
                evento.setData(rs.getString("data"));
                evento.setHora(rs.getString("hora"));
                evento.setIdLocal(rs.getInt("fk_id_local"));
                evento.setLocal(localDAO.buscarPorId(evento.getIdLocal()));
                eventos.add(evento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return eventos;
    }
    
    public Evento buscarPorId(int id) {
        String sql = "SELECT * FROM evento WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Evento evento = new Evento();
                evento.setId(rs.getInt("pk_id"));
                evento.setNome(rs.getString("nome"));
                evento.setDescricao(rs.getString("descricao"));
                evento.setData(rs.getString("data"));
                evento.setHora(rs.getString("hora"));
                evento.setIdLocal(rs.getInt("fk_id_local"));
                
                LocalDAO localDAO = new LocalDAO();
                evento.setLocal(localDAO.buscarPorId(evento.getIdLocal()));
                
                return evento;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean atualizar(Evento evento) {
        String sql = "UPDATE evento SET nome = ?, descricao = ?, data = ?, hora = ?, fk_id_local = ? WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, evento.getNome());
            stmt.setString(2, evento.getDescricao());
            stmt.setString(3, evento.getData());
            stmt.setString(4, evento.getHora());
            stmt.setInt(5, evento.getIdLocal());
            stmt.setInt(6, evento.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deletar(int id) {
        String sql = "DELETE FROM evento WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}