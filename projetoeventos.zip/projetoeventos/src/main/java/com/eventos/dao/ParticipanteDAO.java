package com.eventos.dao;

import com.eventos.model.Participante;
import com.eventos.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParticipanteDAO {
    
    public boolean inserir(Participante participante) {
        String sql = "INSERT INTO participante (nome, email, telefone) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, participante.getNome());
            stmt.setString(2, participante.getEmail());
            stmt.setString(3, participante.getTelefone());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Participante> listar() {
        List<Participante> participantes = new ArrayList<>();
        String sql = "SELECT * FROM participante ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Participante participante = new Participante();
                participante.setId(rs.getInt("pk_id"));
                participante.setNome(rs.getString("nome"));
                participante.setEmail(rs.getString("email"));
                participante.setTelefone(rs.getString("telefone"));
                participantes.add(participante);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return participantes;
    }
    
    public Participante buscarPorId(int id) {
        String sql = "SELECT * FROM participante WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Participante participante = new Participante();
                participante.setId(rs.getInt("pk_id"));
                participante.setNome(rs.getString("nome"));
                participante.setEmail(rs.getString("email"));
                participante.setTelefone(rs.getString("telefone"));
                return participante;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean atualizar(Participante participante) {
        String sql = "UPDATE participante SET nome = ?, email = ?, telefone = ? WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, participante.getNome());
            stmt.setString(2, participante.getEmail());
            stmt.setString(3, participante.getTelefone());
            stmt.setInt(4, participante.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deletar(int id) {
        String sql = "DELETE FROM participante WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}