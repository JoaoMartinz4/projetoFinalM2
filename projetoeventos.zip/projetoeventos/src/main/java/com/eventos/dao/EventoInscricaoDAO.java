package com.eventos.dao;

import com.eventos.model.*;
import com.eventos.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventoInscricaoDAO {
    
    // Adiciona participante a um evento
    public boolean adicionarParticipante(int eventoId, int participanteId) {
        String sql = "INSERT INTO evento_participante (fk_id_evento, fk_id_participante) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventoId);
            stmt.setInt(2, participanteId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Remove participante de um evento
    public boolean removerParticipante(int eventoId, int participanteId) {
        String sql = "DELETE FROM evento_participante WHERE fk_id_evento = ? AND fk_id_participante = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventoId);
            stmt.setInt(2, participanteId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Adiciona palestrante a um evento
    public boolean adicionarPalestrante(int eventoId, int palestranteId) {
        String sql = "INSERT INTO evento_palestrante (fk_id_evento, fk_id_palestrante) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventoId);
            stmt.setInt(2, palestranteId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Remove palestrante de um evento
    public boolean removerPalestrante(int eventoId, int palestranteId) {
        String sql = "DELETE FROM evento_palestrante WHERE fk_id_evento = ? AND fk_id_palestrante = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventoId);
            stmt.setInt(2, palestranteId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Lista participantes de um evento
    public List<Participante> listarParticipantes(int eventoId) {
        List<Participante> participantes = new ArrayList<>();
        String sql = "SELECT p.* FROM participante p " +
                     "INNER JOIN evento_participante ep ON p.pk_id = ep.fk_id_participante " +
                     "WHERE ep.fk_id_evento = ? " +
                     "ORDER BY p.nome";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventoId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Participante p = new Participante();
                p.setId(rs.getInt("pk_id"));
                p.setNome(rs.getString("nome"));
                p.setEmail(rs.getString("email"));
                p.setTelefone(rs.getString("telefone"));
                participantes.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return participantes;
    }
    
    // Lista palestrantes de um evento
    public List<Palestrante> listarPalestrantes(int eventoId) {
        List<Palestrante> palestrantes = new ArrayList<>();
        String sql = "SELECT p.* FROM palestrante p " +
                     "INNER JOIN evento_palestrante ep ON p.pk_id = ep.fk_id_palestrante " +
                     "WHERE ep.fk_id_evento = ? " +
                     "ORDER BY p.nome";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventoId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Palestrante p = new Palestrante();
                p.setId(rs.getInt("pk_id"));
                p.setNome(rs.getString("nome"));
                p.setEmail(rs.getString("email"));
                p.setEspecialidade(rs.getString("especialidade"));
                palestrantes.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return palestrantes;
    }
    
    // Conta participantes de um evento
    public int contarParticipantes(int eventoId) {
        String sql = "SELECT COUNT(*) as total FROM evento_participante WHERE fk_id_evento = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventoId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    // Verifica se participante já está inscrito
    public boolean participanteJaInscrito(int eventoId, int participanteId) {
        String sql = "SELECT COUNT(*) as total FROM evento_participante " +
                     "WHERE fk_id_evento = ? AND fk_id_participante = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventoId);
            stmt.setInt(2, participanteId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("total") > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}