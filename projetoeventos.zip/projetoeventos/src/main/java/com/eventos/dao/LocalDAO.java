package com.eventos.dao;

import com.eventos.model.Local;
import com.eventos.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LocalDAO {
    
    public boolean inserir(Local local) {
        String sql = "INSERT INTO local (nome, endereco, capacidade) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, local.getNome());
            stmt.setString(2, local.getEndereco());
            stmt.setInt(3, local.getCapacidade());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Local> listar() {
        List<Local> locais = new ArrayList<>();
        String sql = "SELECT * FROM local ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Local local = new Local();
                local.setId(rs.getInt("pk_id"));
                local.setNome(rs.getString("nome"));
                local.setEndereco(rs.getString("endereco"));
                local.setCapacidade(rs.getInt("capacidade"));
                locais.add(local);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return locais;
    }
    
    public Local buscarPorId(int id) {
        String sql = "SELECT * FROM local WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Local local = new Local();
                local.setId(rs.getInt("pk_id"));
                local.setNome(rs.getString("nome"));
                local.setEndereco(rs.getString("endereco"));
                local.setCapacidade(rs.getInt("capacidade"));
                return local;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean atualizar(Local local) {
        String sql = "UPDATE local SET nome = ?, endereco = ?, capacidade = ? WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, local.getNome());
            stmt.setString(2, local.getEndereco());
            stmt.setInt(3, local.getCapacidade());
            stmt.setInt(4, local.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deletar(int id) {
        String sql = "DELETE FROM local WHERE pk_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}