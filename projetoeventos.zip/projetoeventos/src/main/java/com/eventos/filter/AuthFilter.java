package com.eventos.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter("/*")
public class AuthFilter implements Filter {
    
    private static final String[] PUBLIC_URLS = {"/login", "/logout"};
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        String path = httpRequest.getRequestURI().substring(httpRequest.getContextPath().length());
        
        // Permite acesso a recursos estáticos e URLs públicas
        if (path.startsWith("/css") || path.startsWith("/js") || 
            path.startsWith("/images") || isPublicUrl(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        // Verifica se usuário está logado
        HttpSession session = httpRequest.getSession(false);
        boolean logado = (session != null && session.getAttribute("usuarioLogado") != null);
        
        if (logado) {
            chain.doFilter(request, response);
        } else {
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
        }
    }
    
    private boolean isPublicUrl(String path) {
        for (String url : PUBLIC_URLS) {
            if (path.equals(url) || path.startsWith(url)) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}
    
    @Override
    public void destroy() {}
}